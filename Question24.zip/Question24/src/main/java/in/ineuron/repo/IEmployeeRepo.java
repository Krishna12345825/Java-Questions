package in.ineuron.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.model.Employee;


public interface IEmployeeRepo extends JpaRepository<Employee, Integer> {

}
