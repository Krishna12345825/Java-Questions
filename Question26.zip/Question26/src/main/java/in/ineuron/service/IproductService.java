package in.ineuron.service;

import in.ineuron.model.Product;

public interface IproductService {

	String createProduct(Product product);
	String updateProduct(Product product);
	String DeleteProduct(long id);
	Product getProductById(long id);
	Iterable<Product> getAllProducts();
	
}
