package in.ineuron.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.exception.ProductNotFoundException;
import in.ineuron.model.Product;
import in.ineuron.repo.ProductRepository;


@Service
public class ProductServiceImpl implements IproductService {

	@Autowired
	ProductRepository productRepository;
	
	@Override
	public String createProduct(Product product) {
    Product product2=   productRepository.save(product);	
		return  "Product is register with Id values "+product2.getId();
	}

	@Override
	public String updateProduct(Product product) {
		Optional<Product> opt=productRepository.findById(product.getId());
		if(opt.isPresent()) {
			productRepository.save(product);  //update object
			return "Actor Information is updated";
		}
		else {
			throw new  ProductNotFoundException("Product not found");
		}
	}

	public String DeleteProduct(long id) {
    Optional<Product> optional =productRepository.findById(id);
	if (optional.isPresent()) {
	 	productRepository.deleteById(id);
	 	return "Product Information is Deleted";
	}	else {
		throw new ProductNotFoundException("Product is Deleted successfully");
	}
	}

	

	@Override
	public Iterable<Product> getAllProducts() {
		Iterable<Product>  it=productRepository.findAll();
		List<Product> list1=(List<Product>)it;
		list1.sort((t1,t2)->t1.getName().compareTo(t2.getName()));
		return  list1;
	}

	@Override
	public Product getProductById(long id) {
		return productRepository.findById(id).orElseThrow(()->new IllegalArgumentException());
	}

}
