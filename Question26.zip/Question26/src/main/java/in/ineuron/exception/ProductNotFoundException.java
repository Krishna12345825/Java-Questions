package in.ineuron.exception;

public class ProductNotFoundException extends RuntimeException {
	
	
	public ProductNotFoundException() {
		super();
	}

	

	
	public ProductNotFoundException( String msg) {
		super(msg);
	}

}
