package in.ineuron.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import in.ineuron.model.Product;
import in.ineuron.repo.ProductRepository;
import in.ineuron.service.ProductServiceImpl;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
 ProductServiceImpl productServiceImpl;
	
	@PostMapping("/save")
	public  ResponseEntity<String>  saveProduct(@RequestBody  Product product ){
		try {
		  //use service
			String msg=productServiceImpl.createProduct(product);
			return  new ResponseEntity<String>(msg,HttpStatus.CREATED);
		}
		catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/report")
	public   ResponseEntity<Iterable<Product>>  fetchAllProducts(){
		try {
		//use  service
		Iterable<Product> list=productServiceImpl.getAllProducts();
		//return  ResponseEntity object
		return new ResponseEntity<Iterable<Product>>(list, HttpStatus.OK);
		}
		catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	@GetMapping("/get/{id}")
	public  ResponseEntity<?> fetchProductId(@PathVariable  long id){
		try { 
			Product products=productServiceImpl.getProductById(id);
			return  new ResponseEntity<Product>(products,HttpStatus.OK);
		}
		catch(Exception e) {
			e.printStackTrace();
			return  new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@PutMapping("/modify")
	public  ResponseEntity<String> modifyProduct(@RequestBody Product product ){
		try {
          String msg=productServiceImpl.updateProduct(product);
          return  new ResponseEntity<String>(msg,HttpStatus.OK);
		}
		catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}//method
	
	
	@DeleteMapping("/delete/{id}")
	public   ResponseEntity<String>  deleteProduct(@PathVariable("id") long id){
		
		try {
			//use service
          String msg=productServiceImpl.DeleteProduct(id);
          return  new ResponseEntity<String>(msg,HttpStatus.OK);
		}
		catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}//method
	

}
