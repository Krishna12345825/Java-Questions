package in.ineuron;
/*
11. Write a Java program that connects to a MySQL database using JDBC. The program
should read data from a table and display the results in the console.
*/

import java.sql.*;

public class Question11 {
   
    	public static void main(String[] args) throws  SQLException {
    		// step2. Establish the connection
    		String url="jdbc:mysql:///octbatch";
    		String user="root";
    		String password="root";
    		Connection connection= DriverManager.getConnection(url, user,password);
    		System.out.println("CONNECTION object created...");
    		
    		// step3. create the statement object and send the query 
    		Statement statement= connection.createStatement();
    		System.out.println("STATEMENT object created...");
    		
    		// Step4. Execute the Query and Process the resultSet
    		
    		String sqlSelectQuery="select sid,sname,sage,saddress from student";
    		ResultSet resultSet= statement.executeQuery(sqlSelectQuery);
    		System.out.println("RESULTSET object created...");
    		System.out.println("SID\tSNAME\tSAGE\tSADDRESS");
    		while (resultSet.next()) {
    			int sid = resultSet.getInt("sid");
    			String sname = resultSet.getString("sname");
    			int sage = resultSet.getInt("sage");
    			String saddress = resultSet.getString("saddress");
    			System.out.println(sid + "\t" + sname + "\t" + sage + "\t" + saddress);
    		}
    		
    		// Step6. Close the resources
    				resultSet.close();
    				statement.close();
    				connection.close();
    				System.out.println("Closing the resources...");
    	}
    	
}
