package in.ineuron.service;

import in.ineuron.dto.UserDto;
import in.ineuron.model.User;

import java.util.List;

public interface UserService {
    void saveUser(UserDto userDto);

    User findByEmail(String email);

    List<UserDto> findAllUsers();
}
