package in.ineuron.hotel.service;

import java.util.List;

import in.ineuron.hotel.entities.Hotel;

public interface HotelService {
	
	// create 
	Hotel create(Hotel hotel);
	
	
	// get All 
	List<Hotel> getAll();
	
	
	// get single
	Hotel get(String id);

}
